/*
 * Tiny Tapeout VGA
 * MetroBus Psychedelic
 *
 * Juego VGA ultraligero para Tiny Tapeout.
 *
 * Controles:
 *   ui_in[0] = UP
 *   ui_in[1] = DOWN
 *   ui_in[2] = START / RESTART
 *   ui_in[3] = PSYCHEDELIC MODE
 *
 * Características:
 *   - 640x480 VGA
 *   - RGB222
 *   - 3 carriles
 *   - 1 obstáculo
 *   - MetroBus procedural
 *   - Fondo psicodélico procedural
 *   - LFSR para carril aleatorio
 *   - Score binario
 *   - Sin framebuffer
 *   - Sin multiplicadores
 *   - Sin divisores
 *   - Sin ROM de sprites
 */

`default_nettype none


module tt_um_vga_example(
    input  wire [7:0] ui_in,
    output wire [7:0] uo_out,

    input  wire [7:0] uio_in,
    output wire [7:0] uio_out,
    output wire [7:0] uio_oe,

    input  wire       ena,
    input  wire       clk,
    input  wire       rst_n
);

    // =========================================================
    // VGA
    // =========================================================

    wire hsync;
    wire vsync;

    wire video_active;

    wire [9:0] pix_x;
    wire [9:0] pix_y;

    wire [1:0] R;
    wire [1:0] G;
    wire [1:0] B;


    // TinyVGA PMOD
    assign uo_out = {
        hsync,
        B[0],
        G[0],
        R[0],
        vsync,
        B[1],
        G[1],
        R[1]
    };


    assign uio_out = 8'b00000000;
    assign uio_oe  = 8'b00000000;


    // =========================================================
    // VGA TIMING
    // =========================================================

    hvsync_generator hvsync_gen (
        .clk(clk),
        .reset(~rst_n),

        .hsync(hsync),
        .vsync(vsync),

        .display_on(video_active),

        .hpos(pix_x),
        .vpos(pix_y)
    );


    // =========================================================
    // FRAME TICK
    // =========================================================
    //
    // Un pulso por frame.
    //
    // Toda la lógica del juego se actualiza solamente
    // una vez por cuadro.
    //
    // =========================================================

    wire frame_tick;

    assign frame_tick =
        (pix_x == 10'd0) &&
        (pix_y == 10'd0);


    // =========================================================
    // FRAME COUNTER
    // =========================================================

    reg [11:0] frame_counter;

    always @(posedge clk or negedge rst_n) begin

        if (!rst_n) begin

            frame_counter <= 12'd0;

        end
        else if (frame_tick) begin

            frame_counter <= frame_counter + 12'd1;

        end

    end


    // =========================================================
    // BUTTON EDGE DETECTION
    // =========================================================
    //
    // Los botones se muestrean una vez por frame.
    //
    // Evita que mantener presionado UP cambie 60 veces
    // de carril por segundo.
    //
    // =========================================================

    reg prev_up;
    reg prev_down;
    reg prev_start;

    wire press_up;
    wire press_down;
    wire press_start;

    assign press_up =
        ui_in[0] && !prev_up;

    assign press_down =
        ui_in[1] && !prev_down;

    assign press_start =
        ui_in[2] && !prev_start;


    always @(posedge clk or negedge rst_n) begin

        if (!rst_n) begin

            prev_up    <= 1'b0;
            prev_down  <= 1'b0;
            prev_start <= 1'b0;

        end
        else if (frame_tick) begin

            prev_up    <= ui_in[0];
            prev_down  <= ui_in[1];
            prev_start <= ui_in[2];

        end

    end


    // =========================================================
    // GAME STATES
    // =========================================================

    localparam STATE_WAIT = 2'd0;
    localparam STATE_PLAY = 2'd1;
    localparam STATE_LOST = 2'd2;

    reg [1:0] game_state;


    // =========================================================
    // PLAYER
    // =========================================================
    //
    // lane:
    //
    // 0 = superior
    // 1 = central
    // 2 = inferior
    //
    // =========================================================

    reg [1:0] bus_lane;


    // =========================================================
    // OBSTACLE
    // =========================================================

    reg [9:0] obstacle_x;
    reg [1:0] obstacle_lane;


    // =========================================================
    // SCORE
    // =========================================================

    reg [7:0] score;


    // =========================================================
    // RANDOM GENERATOR
    // =========================================================
    //
    // LFSR de 8 bits.
    //
    // Muy barato en hardware.
    //
    // =========================================================

    reg [7:0] lfsr;

    wire lfsr_feedback;

    assign lfsr_feedback =
        lfsr[7] ^
        lfsr[5] ^
        lfsr[4] ^
        lfsr[3];


    // =========================================================
    // COLLISION
    // =========================================================
    //
    // MetroBus:
    //
    // X = aproximadamente 70..145
    //
    // obstáculo = 24 pixels
    //
    // Solo necesitamos saber si:
    //
    // - están en el mismo carril
    // - obstacle_x entra en el área del bus
    //
    // =========================================================

    wire collision;

    assign collision =

        (game_state == STATE_PLAY)

        &&

        (obstacle_lane == bus_lane)

        &&

        (obstacle_x < 10'd145)

        &&

        (obstacle_x > 10'd48);


    // =========================================================
    // GAME LOGIC
    // =========================================================

    always @(posedge clk or negedge rst_n) begin

        if (!rst_n) begin

            game_state    <= STATE_WAIT;

            bus_lane      <= 2'd1;

            obstacle_x    <= 10'd620;
            obstacle_lane <= 2'd0;

            score         <= 8'd0;

            lfsr          <= 8'b10101101;

        end

        else if (frame_tick) begin

            // ---------------------------------------------
            // Update LFSR
            // ---------------------------------------------

            lfsr <= {
                lfsr[6:0],
                lfsr_feedback
            };


            // =============================================
            // WAITING
            // =============================================

            if (game_state == STATE_WAIT) begin

                obstacle_x <= 10'd620;

                score <= 8'd0;

                bus_lane <= 2'd1;


                if (press_start) begin

                    game_state <= STATE_PLAY;

                end

            end


            // =============================================
            // PLAYING
            // =============================================

            else if (game_state == STATE_PLAY) begin


                // -----------------------------------------
                // Player movement
                // -----------------------------------------

                if (press_up) begin

                    if (bus_lane != 2'd0)

                        bus_lane <= bus_lane - 2'd1;

                end


                else if (press_down) begin

                    if (bus_lane != 2'd2)

                        bus_lane <= bus_lane + 2'd1;

                end


                // -----------------------------------------
                // Collision
                // -----------------------------------------

                if (collision) begin

                    game_state <= STATE_LOST;

                end


                // -----------------------------------------
                // Move obstacle
                // -----------------------------------------

                else begin

                    if (obstacle_x > 10'd4) begin

                        obstacle_x <= obstacle_x - 10'd4;

                    end

                    else begin

                        obstacle_x <= 10'd620;

                        score <= score + 8'd1;


                        // ---------------------------------
                        // pseudo-random lane
                        // ---------------------------------

                        case (lfsr[1:0])

                            2'd0:
                                obstacle_lane <= 2'd0;

                            2'd1:
                                obstacle_lane <= 2'd1;

                            2'd2:
                                obstacle_lane <= 2'd2;

                            default:
                                obstacle_lane <= 2'd1;

                        endcase

                    end

                end

            end


            // =============================================
            // LOST
            // =============================================

            else begin

                if (press_start) begin

                    game_state    <= STATE_PLAY;

                    bus_lane      <= 2'd1;

                    obstacle_x    <= 10'd620;

                    obstacle_lane <= 2'd0;

                    score         <= 8'd0;

                end

            end

        end

    end


    // =========================================================
    // BUS Y POSITION
    // =========================================================

    reg [9:0] bus_y;

    always @(*) begin

        case (bus_lane)

            2'd0:
                bus_y = 10'd260;

            2'd1:
                bus_y = 10'd340;

            default:
                bus_y = 10'd420;

        endcase

    end


    // =========================================================
    // OBSTACLE Y POSITION
    // =========================================================

    reg [9:0] obstacle_y;

    always @(*) begin

        case (obstacle_lane)

            2'd0:
                obstacle_y = 10'd267;

            2'd1:
                obstacle_y = 10'd347;

            default:
                obstacle_y = 10'd427;

        endcase

    end


    // =========================================================
    // METROBUS
    // =========================================================
    //
    // Dibujado únicamente con rectángulos.
    //
    // No sprite ROM.
    //
    // =========================================================

    localparam BUS_X = 10'd70;


    // Main body
    wire bus_body;

    assign bus_body =

        (pix_x >= BUS_X) &&
        (pix_x <  BUS_X + 10'd75) &&

        (pix_y >= bus_y) &&
        (pix_y <  bus_y + 10'd32);


    // Roof
    wire bus_roof;

    assign bus_roof =

        (pix_x >= BUS_X + 10'd8) &&
        (pix_x <  BUS_X + 10'd63) &&

        (pix_y >= bus_y - 10'd6) &&
        (pix_y <  bus_y);


    // Front
    wire bus_front;

    assign bus_front =

        (pix_x >= BUS_X + 10'd65) &&
        (pix_x <  BUS_X + 10'd78) &&

        (pix_y >= bus_y + 10'd8) &&
        (pix_y <  bus_y + 10'd31);


    // Windows
    wire bus_windows;

    assign bus_windows =

        (pix_x >= BUS_X + 10'd10) &&
        (pix_x <  BUS_X + 10'd60) &&

        (pix_y >= bus_y + 10'd5) &&
        (pix_y <  bus_y + 10'd14) &&

        (pix_x[3:0] < 4'd11);


    // Black stripe
    wire bus_stripe;

    assign bus_stripe =

        (pix_x >= BUS_X) &&
        (pix_x <  BUS_X + 10'd75) &&

        (pix_y >= bus_y + 10'd19) &&
        (pix_y <  bus_y + 10'd22);


    // Wheel 1
    wire wheel1;

    assign wheel1 =

        (pix_x >= BUS_X + 10'd12) &&
        (pix_x <  BUS_X + 10'd24) &&

        (pix_y >= bus_y + 10'd28) &&
        (pix_y <  bus_y + 10'd37);


    // Wheel 2
    wire wheel2;

    assign wheel2 =

        (pix_x >= BUS_X + 10'd53) &&
        (pix_x <  BUS_X + 10'd65) &&

        (pix_y >= bus_y + 10'd28) &&
        (pix_y <  bus_y + 10'd37);


    wire bus_pixel;

    assign bus_pixel =
        bus_body ||
        bus_roof ||
        bus_front;


    wire wheel_pixel;

    assign wheel_pixel =
        wheel1 ||
        wheel2;


    // =========================================================
    // OBSTACLE
    // =========================================================

    wire obstacle_body;

    assign obstacle_body =

        (pix_x >= obstacle_x) &&
        (pix_x < obstacle_x + 10'd24) &&

        (pix_y >= obstacle_y) &&
        (pix_y < obstacle_y + 10'd26);


    // Small upper block
    wire obstacle_top;

    assign obstacle_top =

        (pix_x >= obstacle_x + 10'd6) &&
        (pix_x < obstacle_x + 10'd18) &&

        (pix_y >= obstacle_y - 10'd8) &&
        (pix_y < obstacle_y);


    wire obstacle_pixel;

    assign obstacle_pixel =
        obstacle_body ||
        obstacle_top;


    // =========================================================
    // ROAD
    // =========================================================

    wire road;

    assign road =
        (pix_y >= 10'd240);


    // Lane boundaries
    wire lane_line;

    assign lane_line =

        (
            (pix_y >= 10'd318) &&
            (pix_y <  10'd322)
        )

        ||

        (
            (pix_y >= 10'd398) &&
            (pix_y <  10'd402)
        );


    // =========================================================
    // MOVING ROAD DASHES
    // =========================================================
    //
    // Movimiento horizontal muy barato.
    //
    // =========================================================

    wire [9:0] moving_road_x;

    assign moving_road_x =
        pix_x +
        {frame_counter[7:0], 2'b00};


    wire road_dash;

    assign road_dash =

        lane_line

        &&

        (moving_road_x[5] == 1'b0);


    // =========================================================
    // SIDE ROAD EFFECT
    // =========================================================

    wire road_speed_line;

    assign road_speed_line =

        road

        &&

        (pix_y[4:0] == frame_counter[4:0]);


    // =========================================================
    // PSYCHEDELIC SKY
    // =========================================================
    //
    // No seno/coseno.
    //
    // Combinamos X, Y y frame counter.
    //
    // =========================================================

    wire [7:0] psych_phase;

    assign psych_phase =

        pix_x[7:0]

        +

        {pix_y[6:0], 1'b0}

        +

        frame_counter[7:0];


    // Diagonal lines
    wire psych_line1;

    assign psych_line1 =

        (
            psych_phase[4:0] == 5'd0
        );


    // Opposite diagonal pattern
    wire [7:0] psych_phase2;

    assign psych_phase2 =

        pix_x[7:0]

        -

        pix_y[7:0]

        +

        frame_counter[7:0];


    wire psych_line2;

    assign psych_line2 =

        (
            psych_phase2[4:0] == 5'd0
        );


    // XOR texture
    wire psych_grid;

    assign psych_grid =

        (
            (
                pix_x[5:0] ^
                pix_y[5:0] ^
                frame_counter[5:0]
            )
            < 6'd2
        );


    // =========================================================
    // SKY AREA
    // =========================================================

    wire sky;

    assign sky =
        (pix_y < 10'd240);


    // =========================================================
    // HORIZON
    // =========================================================

    wire horizon;

    assign horizon =

        (pix_y >= 10'd234) &&
        (pix_y <  10'd240);


    // =========================================================
    // SUN
    // =========================================================
    //
    // Octagonal/diamond-like psychedelic sun.
    //
    // No multiplication.
    //
    // abs(x-520) + abs(y-90) < 45
    //
    // =========================================================

    wire [9:0] sun_dx;
    wire [9:0] sun_dy;

    assign sun_dx =
        (pix_x >= 10'd520)
        ? pix_x - 10'd520
        : 10'd520 - pix_x;

    assign sun_dy =
        (pix_y >= 10'd90)
        ? pix_y - 10'd90
        : 10'd90 - pix_y;


    wire sun;

    assign sun =
        (sun_dx + sun_dy) < 10'd48;


    wire sun_lines;

    assign sun_lines =

        sun &&

        (
            (
                pix_y[3:0] +
                frame_counter[3:0]
            )
            < 4'd3
        );


    // =========================================================
    // SCORE DISPLAY
    // =========================================================
    //
    // 8 bits del score dibujados arriba a la izquierda.
    //
    // █ █   █ ...
    //
    // Esto evita una fuente completa.
    //
    // =========================================================

    wire score_area;

    assign score_area =

        (pix_y >= 10'd20) &&
        (pix_y <  10'd35) &&

        (pix_x >= 10'd20) &&
        (pix_x <  10'd148);


    wire [3:0] score_column;

    assign score_column =
        (pix_x - 10'd20) >> 4;


    reg score_pixel;

    always @(*) begin

        score_pixel = 1'b0;

        if (score_area) begin

            case (score_column)

                4'd0:
                    score_pixel = score[7];

                4'd1:
                    score_pixel = score[6];

                4'd2:
                    score_pixel = score[5];

                4'd3:
                    score_pixel = score[4];

                4'd4:
                    score_pixel = score[3];

                4'd5:
                    score_pixel = score[2];

                4'd6:
                    score_pixel = score[1];

                4'd7:
                    score_pixel = score[0];

                default:
                    score_pixel = 1'b0;

            endcase

        end

    end


    // =========================================================
    // START INDICATOR
    // =========================================================

    wire start_box;

    assign start_box =

        (game_state == STATE_WAIT)

        &&

        (pix_x >= 10'd250) &&
        (pix_x <  10'd390) &&

        (pix_y >= 10'd90) &&
        (pix_y <  10'd130);


    wire start_inner;

    assign start_inner =

        (pix_x >= 10'd258) &&
        (pix_x <  10'd382) &&

        (pix_y >= 10'd98) &&
        (pix_y <  10'd122);


    // =========================================================
    // GAME OVER EFFECT
    // =========================================================

    wire game_over_pattern;

    assign game_over_pattern =

        (game_state == STATE_LOST)

        &&

        (
            pix_x[5] ^
            pix_y[5] ^
            frame_counter[3]
        );


    // =========================================================
    // PSYCHEDELIC COLOR PALETTE
    // =========================================================

    wire [2:0] hue;

    assign hue =

        psych_phase[7:5]

        +

        frame_counter[5:3];


    reg [1:0] psych_r;
    reg [1:0] psych_g;
    reg [1:0] psych_b;


    always @(*) begin

        case (hue)

            3'd0: begin
                psych_r = 2'b11;
                psych_g = 2'b00;
                psych_b = 2'b01;
            end

            3'd1: begin
                psych_r = 2'b11;
                psych_g = 2'b01;
                psych_b = 2'b00;
            end

            3'd2: begin
                psych_r = 2'b11;
                psych_g = 2'b11;
                psych_b = 2'b00;
            end

            3'd3: begin
                psych_r = 2'b00;
                psych_g = 2'b11;
                psych_b = 2'b00;
            end

            3'd4: begin
                psych_r = 2'b00;
                psych_g = 2'b11;
                psych_b = 2'b11;
            end

            3'd5: begin
                psych_r = 2'b00;
                psych_g = 2'b01;
                psych_b = 2'b11;
            end

            3'd6: begin
                psych_r = 2'b10;
                psych_g = 2'b00;
                psych_b = 2'b11;
            end

            default: begin
                psych_r = 2'b11;
                psych_g = 2'b00;
                psych_b = 2'b11;
            end

        endcase

    end


    // =========================================================
    // FINAL COLOR GENERATOR
    // =========================================================

    reg [1:0] pixel_r;
    reg [1:0] pixel_g;
    reg [1:0] pixel_b;


    always @(*) begin

        // Background
        pixel_r = 2'b00;
        pixel_g = 2'b00;
        pixel_b = 2'b00;


        // =====================================================
        // SKY
        // =====================================================

        if (sky) begin

            // Psychedelic mode
            if (ui_in[3]) begin

                pixel_r = {
                    psych_phase[7],
                    psych_phase[5]
                };

                pixel_g = {
                    psych_phase[6],
                    psych_phase[4]
                };

                pixel_b = {
                    psych_phase[5],
                    psych_phase[7]
                };


                if (
                    psych_line1 ||
                    psych_line2 ||
                    psych_grid
                ) begin

                    pixel_r = psych_r;
                    pixel_g = psych_g;
                    pixel_b = psych_b;

                end

            end

            // Normal night mode
            else begin

                pixel_r = 2'b00;
                pixel_g = 2'b00;
                pixel_b = 2'b01;


                if (
                    psych_line1 ||
                    psych_grid
                ) begin

                    pixel_r = 2'b00;
                    pixel_g = 2'b01;
                    pixel_b = 2'b10;

                end

            end

        end


        // =====================================================
        // PSYCHEDELIC SUN
        // =====================================================

        if (sun) begin

            pixel_r = 2'b11;
            pixel_g = 2'b01;
            pixel_b = 2'b00;

        end


        if (sun_lines) begin

            pixel_r = 2'b11;
            pixel_g = 2'b00;
            pixel_b = 2'b10;

        end


        // =====================================================
        // HORIZON
        // =====================================================

        if (horizon) begin

            pixel_r = psych_r;
            pixel_g = psych_g;
            pixel_b = psych_b;

        end


        // =====================================================
        // ROAD
        // =====================================================

        if (road) begin

            pixel_r = 2'b00;
            pixel_g = 2'b00;
            pixel_b = 2'b01;

        end


        // moving horizontal road texture
        if (road_speed_line) begin

            pixel_r = 2'b01;
            pixel_g = 2'b00;
            pixel_b = 2'b01;

        end


        // =====================================================
        // LANE DIVIDERS
        // =====================================================

        if (lane_line) begin

            pixel_r = 2'b01;
            pixel_g = 2'b01;
            pixel_b = 2'b01;

        end


        if (road_dash) begin

            pixel_r = 2'b11;
            pixel_g = 2'b11;
            pixel_b = 2'b00;

        end


        // =====================================================
        // OBSTACLE
        // =====================================================

        if (obstacle_pixel) begin

            pixel_r = 2'b11;
            pixel_g = 2'b00;
            pixel_b = 2'b00;

        end


        // =====================================================
        // BUS
        // =====================================================

        if (bus_pixel) begin

            // psychedelic bus
            if (ui_in[3]) begin

                pixel_r = psych_r;
                pixel_g = psych_g;
                pixel_b = psych_b;

            end

            // normal MetroBus
            else begin

                pixel_r = 2'b11;
                pixel_g = 2'b01;
                pixel_b = 2'b00;

            end

        end


        // windows
        if (bus_windows) begin

            pixel_r = 2'b00;
            pixel_g = 2'b11;
            pixel_b = 2'b11;

        end


        // stripe
        if (bus_stripe) begin

            pixel_r = 2'b00;
            pixel_g = 2'b00;
            pixel_b = 2'b00;

        end


        // wheels
        if (wheel_pixel) begin

            pixel_r = 2'b00;
            pixel_g = 2'b00;
            pixel_b = 2'b00;

        end


        // =====================================================
        // SCORE
        // =====================================================

        if (score_pixel) begin

            pixel_r = 2'b11;
            pixel_g = 2'b11;
            pixel_b = 2'b11;

        end


        // =====================================================
        // START BOX
        // =====================================================

        if (start_box) begin

            pixel_r = 2'b11;
            pixel_g = 2'b00;
            pixel_b = 2'b11;

        end


        if (
            start_box &&
            start_inner
        ) begin

            pixel_r = 2'b00;
            pixel_g = 2'b00;
            pixel_b = 2'b00;

        end


        // =====================================================
        // GAME OVER
        // =====================================================

        if (game_over_pattern) begin

            pixel_r = 2'b11;
            pixel_g = 2'b00;
            pixel_b = 2'b00;

        end

    end


    // =========================================================
    // OUTPUT
    // =========================================================

    assign R =
        video_active
        ? pixel_r
        : 2'b00;

    assign G =
        video_active
        ? pixel_g
        : 2'b00;

    assign B =
        video_active
        ? pixel_b
        : 2'b00;


    // =========================================================
    // UNUSED INPUTS
    // =========================================================

    wire _unused_ok;

    assign _unused_ok =
        &{
            ena,
            ui_in[7:4],
            uio_in,
            1'b0
        };


endmodule



// =============================================================
// VGA GENERATOR
// =============================================================
//
// Standard VGA 640x480 timing.
//
// IMPORTANT:
// This expects approximately a 25 MHz pixel clock.
//
// Tiny Tapeout clock configuration must therefore correspond
// to the VGA timing you intend to use.
//
// =============================================================

module hvsync_generator(
    input  wire       clk,
    input  wire       reset,

    output wire       hsync,
    output wire       vsync,

    output wire       display_on,

    output wire [9:0] hpos,
    output wire [9:0] vpos
);

    // ---------------------------------------------------------
    // Horizontal
    // ---------------------------------------------------------

    localparam H_VISIBLE = 640;
    localparam H_FRONT   = 16;
    localparam H_SYNC    = 96;
    localparam H_BACK    = 48;

    localparam H_TOTAL =
        H_VISIBLE +
        H_FRONT +
        H_SYNC +
        H_BACK;


    // ---------------------------------------------------------
    // Vertical
    // ---------------------------------------------------------

    localparam V_VISIBLE = 480;
    localparam V_FRONT   = 10;
    localparam V_SYNC    = 2;
    localparam V_BACK    = 33;

    localparam V_TOTAL =
        V_VISIBLE +
        V_FRONT +
        V_SYNC +
        V_BACK;


    reg [9:0] h_counter;
    reg [9:0] v_counter;


    // =========================================================
    // COUNTERS
    // =========================================================

    always @(posedge clk) begin

        if (reset) begin

            h_counter <= 10'd0;
            v_counter <= 10'd0;

        end

        else begin

            if (h_counter == H_TOTAL - 1) begin

                h_counter <= 10'd0;


                if (v_counter == V_TOTAL - 1) begin

                    v_counter <= 10'd0;

                end

                else begin

                    v_counter <= v_counter + 10'd1;

                end

            end

            else begin

                h_counter <= h_counter + 10'd1;

            end

        end

    end


    assign hpos = h_counter;
    assign vpos = v_counter;


    // =========================================================
    // DISPLAY ACTIVE
    // =========================================================

    assign display_on =

        (h_counter < H_VISIBLE)

        &&

        (v_counter < V_VISIBLE);


    // =========================================================
    // HSYNC
    // =========================================================

    assign hsync =

        ~(
            (h_counter >= H_VISIBLE + H_FRONT)

            &&

            (h_counter <
                H_VISIBLE +
                H_FRONT +
                H_SYNC)
        );


    // =========================================================
    // VSYNC
    // =========================================================

    assign vsync =

        ~(
            (v_counter >= V_VISIBLE + V_FRONT)

            &&

            (v_counter <
                V_VISIBLE +
                V_FRONT +
                V_SYNC)
        );


endmodule


`default_nettype wire